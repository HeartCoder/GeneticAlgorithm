
export const meghalayaDestinations = [
  {
    id: "cherrapunji",
    name: "Cherrapunji (Sohra)",
    tagline: "The Land of Living Root Bridges and Waterfalls",
    description: "Cherrapunji, locally known as Sohra, is famed for its double-decker living root bridges, breathtaking waterfalls like Nohkalikai and Seven Sisters Falls, and mysterious caves such as Mawsmai Cave. It's a paradise for nature lovers and adventure seekers.",
    duration: "2-3 days",
    bestTime: "October to May",
    priceRange: "₹7,999 - ₹15,999",
    images: [
      { id: 1, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d4a4a3828aa2214cba3aea1001eb7ed5.jpg", alt: "Double Decker Living Root Bridge in Cherrapunji", text: "The iconic Double Decker Living Root Bridge, a marvel of bio-engineering by the Khasi tribes." },
      { id: 2, url: "https://images.unsplash.com/photo-1581326002021-ba3f4abd127e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bm9oa2FsaWthaSUyMGZhbGxzfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60", alt: "Nohkalikai Falls, Cherrapunji", text: "Nohkalikai Falls, one of the tallest plunge waterfalls in India, cascading down into a turquoise pool." },
      { id: 3, url: "https://images.unsplash.com/photo-1605287789001-c9866c373918?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8bWF3c21haSUyMGNhdmV8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Mawsmai Cave, Cherrapunji", text: "Exploring the illuminated Mawsmai Cave, known for its stalactites and stalagmites." },
      { id: 4, url: "https://images.unsplash.com/photo-1621675099011-ea333900e8e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8c2V2ZW4lMjBzaXN0ZXJzJTIwZmFsbHN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Seven Sisters Falls, Cherrapunji", text: "The majestic Seven Sisters Falls, a seven-segmented waterfall plunging over limestone cliffs." },
    ],
    itinerary: {
      source: "Guwahati",
      days: [
        {
          day: 1,
          title: "Guwahati to Cherrapunji & Local Sightseeing",
          activities: [
            "Early morning pickup from Guwahati and drive to Cherrapunji (approx. 5-6 hours).",
            "En route, visit Umiam Lake (Barapani) for a scenic view.",
            "Check into your hotel in Cherrapunji.",
            "After lunch, visit Mawsmai Cave and Seven Sisters Falls.",
            "Evening at leisure. Overnight stay in Cherrapunji."
          ]
        },
        {
          day: 2,
          title: "Living Root Bridges & Nohkalikai Falls",
          activities: [
            "After breakfast, trek to the Double Decker Living Root Bridge in Nongriat village (requires moderate fitness, approx. 3-4 hours round trip).",
            "Explore the unique bio-engineered bridges and natural pools.",
            "Later, visit Nohkalikai Falls and Eco Park.",
            "Optional: Visit Dainthlen Falls and Wei Sawdong Falls if time permits.",
            "Overnight stay in Cherrapunji."
          ]
        },
        {
          day: 3,
          title: "Return to Guwahati",
          activities: [
            "After breakfast, check out from the hotel.",
            "Drive back to Guwahati.",
            "Optional: Visit Shillong Peak and Elephant Falls on the way if not covered earlier.",
            "Drop-off at Guwahati airport/railway station for your onward journey."
          ]
        }
      ]
    }
  },
  {
    id: "shillong",
    name: "Shillong",
    tagline: "Scotland of the East",
    description: "Shillong, the capital of Meghalaya, is a charming hill station known for its colonial-era architecture, picturesque lakes like Ward's Lake, and vibrant culture. Don Bosco Museum offers deep insights into the local heritage.",
    duration: "2-3 days",
    bestTime: "Year-round",
    priceRange: "₹6,999 - ₹13,999",
    images: [
      { id: 1, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg", alt: "I Love Shillong Sign", text: "A popular 'I Love Shillong' sign in the city center." },
      { id: 2, url: "https://images.unsplash.com/photo-1594008074989-3560390f0509?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZG9uJTIwYm9zY28lMjBtdXNldW0lMjBzaGlsbG9uZ3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60", alt: "Don Bosco Museum, Shillong", text: "The impressive Don Bosco Centre for Indigenous Cultures, showcasing the rich heritage of North East India." },
      { id: 3, url: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2hpbGxvbmclMjBnb2xmJTIwY291cnNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60", alt: "Shillong Golf Course", text: "The lush green Shillong Golf Course, one of the oldest and largest natural golf courses in Asia." },
      { id: 4, url: "https://images.unsplash.com/photo-1605763239300-d52733805167?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cG9saWNlJTIwYmF6YXIlMjBzaGlsbG9uZ3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60", alt: "Police Bazar, Shillong", text: "A bustling street scene from Police Bazar, the commercial hub of Shillong." },
    ],
    itinerary: {
      source: "Guwahati",
      days: [
        {
          day: 1,
          title: "Guwahati to Shillong & Local Sightseeing",
          activities: [
            "Pickup from Guwahati and drive to Shillong (approx. 3-4 hours).",
            "Visit Umiam Lake (Barapani) for boating and scenic views.",
            "Check into your hotel in Shillong.",
            "Afternoon, visit Ward's Lake and Lady Hydari Park.",
            "Evening stroll at Police Bazar. Overnight stay in Shillong."
          ]
        },
        {
          day: 2,
          title: "Shillong Exploration",
          activities: [
            "After breakfast, visit Don Bosco Museum.",
            "Explore Shillong Peak for panoramic views of the city.",
            "Visit Elephant Falls, a three-tiered waterfall.",
            "Optional: Visit the Shillong Golf Course and the Cathedral of Mary Help of Christians.",
            "Overnight stay in Shillong."
          ]
        },
        {
          day: 3,
          title: "Day Trip to Mawlynnong & Dawki (Optional) or Return",
          activities: [
            "Option 1: Full day excursion to Mawlynnong (Asia's cleanest village) and Dawki (Umngot River).",
            "Option 2: After breakfast, check out and drive back to Guwahati for your onward journey."
          ]
        }
      ]
    }
  },
  {
    id: "dawki",
    name: "Dawki",
    tagline: "The Crystal Clear River Town",
    description: "Dawki is renowned for the Umngot River, whose waters are so clear they appear transparent. Boating on the river is a surreal experience, offering views of the riverbed. It's also a border town with Bangladesh.",
    duration: "1-2 days",
    bestTime: "October to March",
    priceRange: "₹4,999 - ₹9,999",
    images: [
      { id: 1, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/4bd73408677d8142fb0f79f4257cfafd.jpg", alt: "Boats on the crystal clear Umngot River, Dawki", text: "Boats appearing to float in mid-air on the transparent waters of the Umngot River." },
      { id: 2, url: "https://images.unsplash.com/photo-1620570624050-968005859398?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZGF3a2klMjBicmlkZ2V8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Suspension bridge over Umngot River, Dawki", text: "The suspension bridge connecting India and Bangladesh near Dawki." },
      { id: 3, url: "https://images.unsplash.com/photo-1605664042008-9f891009091e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGRhd2tpJTIwcml2ZXJ8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "View of the riverbed through clear water in Dawki", text: "A mesmerizing view of the riverbed visible through the crystal clear waters." },
      { id: 4, url: "https://images.unsplash.com/photo-1619785607991-675494f80148?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGRhd2tpJTIwbG9jYWwlMjBsaWZlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60", alt: "Local life near Dawki river", text: "Locals engaging in daily activities along the banks of the Umngot River." },
    ],
    itinerary: {
      source: "Guwahati",
      days: [
        {
          day: 1,
          title: "Guwahati to Dawki via Shillong",
          activities: [
            "Early morning pickup from Guwahati, drive to Dawki (approx. 6-7 hours).",
            "En route, brief stop at Shillong if desired.",
            "Check into your guesthouse/campsite near Dawki/Shnongpdeng.",
            "Afternoon, enjoy boating on the Umngot River.",
            "Visit the India-Bangladesh border. Overnight stay."
          ]
        },
        {
          day: 2,
          title: "Dawki Activities & Return to Guwahati",
          activities: [
            "Morning, explore Shnongpdeng village, try activities like kayaking, snorkeling (seasonal).",
            "Visit the nearby Krang Suri Falls (optional, requires a short trek).",
            "After lunch, drive back to Guwahati.",
            "Drop-off at Guwahati airport/railway station."
          ]
        }
      ]
    }
  },
  {
    id: "mawlynnong",
    name: "Mawlynnong",
    tagline: "Asia's Cleanest Village",
    description: "Mawlynnong is a picturesque village acclaimed for its cleanliness. It offers a glimpse into sustainable Khasi lifestyle, with beautiful gardens, bamboo dustbins, and a nearby living root bridge.",
    duration: "1 day (often combined with Dawki)",
    bestTime: "Year-round",
    priceRange: "₹3,999 - ₹7,999",
    images: [
      { id: 1, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d63a95f696e4b875a8c1514ae90c5979.jpg", alt: "Welcome to Mawlynnong sign", text: "The welcome sign to Mawlynnong, Asia's Cleanest Village." },
      { id: 2, url: "https://images.unsplash.com/photo-1581326002021-ba3f4abd127e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8bGl2aW5nJTIwcm9vdCUyMGJyaWRnZSUyMG1hd2x5bm5vbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Living Root Bridge near Mawlynnong", text: "A single living root bridge near Mawlynnong, showcasing Khasi ingenuity." },
      { id: 3, url: "https://images.unsplash.com/photo-1605287789001-c9866c373918?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2t5JTIwd2FsayUyMG1hd2x5bm5vbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Sky Walk (bamboo watchtower) in Mawlynnong", text: "The Sky Walk, a bamboo watchtower offering panoramic views of the village and Bangladesh plains." },
      { id: 4, url: "https://images.unsplash.com/photo-1581326002021-ba3f4abd127e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8a2hhc2klMjBob3VzZSUyMG1hd2x5bm5vbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60", alt: "Traditional Khasi house in Mawlynnong", text: "A beautifully maintained traditional Khasi house with a blooming garden." },
    ],
    itinerary: {
      source: "Guwahati",
      days: [
        {
          day: 1,
          title: "Guwahati to Mawlynnong & Dawki Day Trip",
          activities: [
            "Very early morning pickup from Guwahati (around 6 AM).",
            "Drive to Mawlynnong (approx. 5-6 hours).",
            "Explore Mawlynnong village, visit the living root bridge and Sky Walk.",
            "Proceed to Dawki (approx. 1 hour from Mawlynnong).",
            "Enjoy boating on the Umngot River.",
            "Late afternoon, start your return journey to Guwahati (approx. 6-7 hours).",
            "Late evening drop-off in Guwahati."
          ]
        }
      ]
    }
  },
  {
    id: "meghalaya-kaziranga-explorer",
    name: "Meghalaya & Kaziranga Explorer",
    tagline: "The Ultimate North East Experience: Clouds, Culture & Wildlife",
    description: "Our journey began from Guwahati, making our way toward the capital of Meghalaya—Shillong. As we climbed through the winding mountain roads, a cool breeze accompanied us, setting the tone for the scenic adventure ahead. Along the way, we stopped at Botapani (also known as Barapani), where the majestic Umiam Lake welcomed us with its serene, expansive beauty—perfectly reflecting the sky above. A visit to the Don Bosco Museum gave us a glimpse into the rich cultural heritage of the Northeast. By evening, we reached Shillong, nestled in the hills and often referred to as the \"Scotland of the East\". The drive from Shillong to Cherrapunji was nothing short of magical. The route took us through misty hills and waterfalls, with stops at key attractions like the breathtaking Elephant Falls. The chilly, fresh air and floating clouds added an ethereal touch to every moment. Reaching Cherrapunji, known as the wettest place on Earth, felt like stepping into a natural wonder. The constant dance of rain and sunshine created a dreamy atmosphere, making it a paradise for nature lovers. This package continues to explore the best of Meghalaya's natural wonders and then ventures into Assam for thrilling wildlife safaris in Kaziranga National Park, culminating back in Guwahati.",
    duration: "3-12 days (flexible)",
    bestTime: "October to April",
    priceRange: "₹14,999 - ₹34,999",
    images: [
      { id: 1, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg", alt: "Shillong City View", text: "Panoramic view of Shillong city." },
      { id: 2, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d4a4a3828aa2214cba3aea1001eb7ed5.jpg", alt: "Double Decker Living Root Bridge, Cherrapunji", text: "Iconic Double Decker Living Root Bridge in Cherrapunji." },
      { id: 3, url: "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/c507eeac7beace3abaa4c7767275caf7.jpg", alt: "One-horned Rhinoceros in Kaziranga National Park", text: "Majestic One-horned Rhinoceros in Kaziranga." },
      { id: 4, url: "https://images.unsplash.com/photo-1605763239300-d52733805167?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cG9saWNlJTIwYmF6YXIlMjBzaGlsbG9uZ3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60", alt: "Umiam Lake (Barapani)", text: "Serene Umiam Lake near Shillong." },
    ],
    itinerary: {
      source: "Guwahati",
      days: [
        {
          day: 1,
          title: "Guwahati to Shillong – A Journey Through the Clouds",
          activities: [
            "Arrive at Guwahati Airport/Railway Station. Our representative will meet you.",
            "Drive towards Shillong (approx. 3-4 hours). Stop at Umiam Lake (Botapani/Barapani) for its serene beauty.",
            "Visit the Don Bosco Museum for insights into North East's cultural heritage.",
            "Check into your hotel in Shillong. Evening free to explore Police Bazar or relax.",
            "Overnight stay in Shillong, the \"Scotland of the East\"."
          ]
        },
        {
          day: 2,
          title: "Shillong to Cherrapunji – Into the Heart of the Rainclouds",
          activities: [
            "After breakfast, drive from Shillong to Cherrapunji (approx. 2 hours).",
            "En route, visit the breathtaking Elephant Falls and Shillong Peak (if time and weather permit).",
            "Experience the misty hills and fresh air. Check into your hotel/resort in Cherrapunji.",
            "Afternoon, visit Nohkalikai Falls (one of India's tallest), Mawsmai Cave, and Seven Sisters Falls.",
            "Overnight stay in Cherrapunji, the land of rain and sunshine."
          ]
        },
        {
          day: 3,
          title: "Cherrapunji - Living Root Bridges & Natural Wonders",
          activities: [
            "Morning, trek to the Double Decker Living Root Bridge in Nongriat (requires fitness, approx. 3-4 hours round trip).",
            "Explore natural pools and the unique bio-engineering of the Khasi tribes.",
            "Alternatively, for a less strenuous day, visit Dainthlen Falls, Wei Sawdong Falls (seasonal), and Eco Park.",
            "Overnight stay in Cherrapunji."
          ]
        },
         {
          day: 4,
          title: "Cherrapunji to Mawlynnong & Dawki",
          activities: [
            "After breakfast, drive to Mawlynnong (approx. 2-3 hours), Asia's Cleanest Village.",
            "Explore the village, visit the local living root bridge and the Sky Walk for panoramic views.",
            "Proceed to Dawki (approx. 1 hour). Enjoy boating on the crystal-clear Umngot River.",
            "Visit the India-Bangladesh border at Tamabil.",
            "Overnight stay near Dawki/Shnongpdeng or return to Shillong/Cherrapunji based on preference and time for longer stays.",
            "(For shorter trips, this day might be combined or skipped. For longer trips, an overnight stay at Dawki/Shnongpdeng is recommended.)"
          ]
        },
        {
          day: 5,
          title: "Meghalaya Exploration / Transfer to Kaziranga National Park",
          activities: [
            "If stayed at Dawki: Morning activities like kayaking/snorkeling (seasonal).",
            "Drive from your Meghalaya base (Cherrapunji/Shillong/Dawki) to Kaziranga National Park (approx. 7-9 hours depending on start point).",
            "This is a long travel day. Break for lunch en route.",
            "Check into your resort near Kaziranga in the evening.",
            "Overnight stay in Kaziranga."
          ]
        },
        {
          day: 6,
          title: "Kaziranga National Park - Wildlife Safaris",
          activities: [
            "Early morning, enjoy an Elephant Safari in one of the park's ranges (Western/Central - subject to availability and booking).",
            "After breakfast, visit the Kaziranga Orchid and Biodiversity Park.",
            "Afternoon, embark on a Jeep Safari in another range (Central/Western/Eastern) for spotting rhinos, tigers (if lucky), deer, and various bird species.",
            "Evening free for leisure or enjoy a traditional Assamese cultural show (if available).",
            "Overnight stay in Kaziranga."
          ]
        },
         {
          day: "7 (Optional: Day 4-11 for extended trips)",
          title: "Additional Exploration / Leisure / Specific Interests",
          activities: [
            "For longer trips (7-12 days):",
            "  - Spend more days in Meghalaya: Explore Jaintia Hills (Krang Suri Falls, Nartiang Monoliths), Garo Hills (Balpakram National Park, Siju Cave).",
            "  - More time in Kaziranga: Additional safaris, visit nearby tea gardens, explore local villages.",
            "  - Add other Assam destinations: Majuli Island, Sivasagar, Manas National Park.",
            "  - Relaxed pace with leisure days.",
            "  - Focus on specific interests: Caving, trekking, birdwatching, cultural immersion.",
            "This day is a placeholder for customizing longer itineraries. Activities depend on chosen duration and interests."
          ]
        },
        {
          day: "Final Day (Day 3, 5, 7 or up to 12)",
          title: "Kaziranga to Guwahati & Departure",
          activities: [
            "After breakfast, check out from the resort in Kaziranga.",
            "Drive back to Guwahati (approx. 4-5 hours).",
            "If time permits, do some last-minute souvenir shopping in Guwahati.",
            "Drop-off at Guwahati Airport/Railway Station for your onward journey.",
            "Note: The total number of days and activities will be adjusted based on the selected package duration (3 to 12 days)."
          ]
        }
      ]
    }
  }
];
