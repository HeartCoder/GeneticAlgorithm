
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Form, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }
    if (!formData.subject.trim()) newErrors.subject = "Subject is required";
    if (!formData.message.trim()) newErrors.message = "Message is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      console.log("Form submitted:", formData);
      toast({
        title: "Message Sent Successfully",
        description: "We'll get back to you as soon as possible.",
        duration: 5000,
      });
      setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
    >
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
        <Form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl><Input name="name" value={formData.name} onChange={handleChange} placeholder="Your full name" /></FormControl>
              {errors.name && <FormMessage>{errors.name}</FormMessage>}
            </FormItem>
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl><Input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Your email address" /></FormControl>
              {errors.email && <FormMessage>{errors.email}</FormMessage>}
            </FormItem>
            <FormItem>
              <FormLabel>Phone Number (Optional)</FormLabel>
              <FormControl><Input name="phone" value={formData.phone} onChange={handleChange} placeholder="Your phone number" /></FormControl>
            </FormItem>
            <FormItem>
              <FormLabel>Subject</FormLabel>
              <FormControl><Input name="subject" value={formData.subject} onChange={handleChange} placeholder="What is your message about?" /></FormControl>
              {errors.subject && <FormMessage>{errors.subject}</FormMessage>}
            </FormItem>
            <FormItem>
              <FormLabel>Message</FormLabel>
              <FormControl><Textarea name="message" value={formData.message} onChange={handleChange} placeholder="Type your message here..." rows={5} /></FormControl>
              {errors.message && <FormMessage>{errors.message}</FormMessage>}
            </FormItem>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">Send Message</Button>
          </div>
        </Form>
      </div>
    </motion.div>
  );
};

export default ContactForm;
