
import React from "react";

const OurTeam = () => {
  return null;
};

export default OurTeam;
