
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Rahul Sharma",
    location: "Mumbai",
    rating: 5,
    text: "Our trip to Meghalaya was absolutely magical! The living root bridges and waterfalls were breathtaking. Our guide was knowledgeable and friendly, making the experience even better.",
    image: "testimonial-1"
  },
  {
    id: 2,
    name: "Priya Patel",
    location: "Bangalore",
    rating: 5,
    text: "The car rental service was excellent. The vehicle was clean and well-maintained, and our driver knew all the best spots. Exploring Kaziranga was a dream come true!",
    image: "testimonial-2"
  },
  {
    id: 3,
    name: "Michael Chen",
    location: "Singapore",
    rating: 5,
    text: "As a photographer, the Dawki River tour was perfect. Crystal clear waters and amazing landscapes. The team went above and beyond to ensure I got the best shots.",
    image: "testimonial-3"
  }
];

const Testimonials = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hear from travelers who have experienced the magic of North East India with our services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full testimonial-card">
                <CardHeader className="pb-4">
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full overflow-hidden h-12 w-12">
                      <img  
                        className="h-full w-full object-cover" 
                        alt={`${testimonial.name} profile picture`}
                       src="https://images.unsplash.com/photo-1598932324015-91232f2bca84" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-500">{testimonial.location}</p>
                    </div>
                  </div>
                  <div className="flex mt-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 italic">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
