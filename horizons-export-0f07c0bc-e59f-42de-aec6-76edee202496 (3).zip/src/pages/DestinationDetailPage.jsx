
import React, { useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Users, MapPin, ArrowLeft, Clock, Sun, CloudRain, IndianRupee } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { getDestinationById } from "@/data/destinationsMaster";

const destinationPageImages = {
  "cherrapunji": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d4a4a3828aa2214cba3aea1001eb7ed5.jpg",
  "shillong": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg",
  "dawki": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/4bd73408677d8142fb0f79f4257cfafd.jpg",
  "mawlynnong": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d63a95f696e4b875a8c1514ae90c5979.jpg",
  "tawang": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/5b9054aafa87ba20a9eb3c2f72756138.jpg",
  "ziro-valley": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/06d7c0128eb2277fd5655a00a3d3f86e.jpg",
  "bomdila": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/45352e7593c05a230fb4ec354cfcd24d.jpg",
  "namdapha-national-park": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/af808dadf7dbee597ca6946d07d2118c.jpg",
  "kaziranga-national-park": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/c507eeac7beace3abaa4c7767275caf7.jpg",
  "majuli-island": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/5f95556e235a02f5423efe9f50c9539b.jpg",
  "guwahati": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/38ca2f376f8bbcad3d6c9a110f87221e.jpg",
  "sivasagar": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/15a65f218b6a89fe2d494ffb02a8522b.jpg",
  "meghalaya-kaziranga-explorer": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg"
};


const DestinationDetailPage = () => {
  const { stateKey, destinationId } = useParams();
  const destination = getDestinationById(stateKey, destinationId);
  const navigate = useNavigate();

  const phoneNumber = "8822608900";
  const countryCode = "+91";
  const whatsappBaseLink = `https://wa.me/${countryCode}${phoneNumber}?text=Hello%2C%20I'm%20interested%20in%20booking%20a%20trip%20to%20`;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [destinationId, stateKey]);

  if (!destination) {
    return (
      <div className="pt-20 md:pt-24 container mx-auto px-4 md:px-6 py-16 text-center">
        <h1 className="text-3xl font-bold text-destructive mb-4">Destination Not Found</h1>
        <p className="text-lg text-gray-600 mb-8">The destination you are looking for does not exist or has been moved.</p>
        <Button onClick={() => navigate("/destinations")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Destinations
        </Button>
      </div>
    );
  }

  const handleBookNow = () => {
    const message = encodeURIComponent(destination.name + ".");
    window.open(whatsappBaseLink + message, '_blank');
  };

  const heroImage = destinationPageImages[destination.id] || destination.images[0]?.url || "https://images.unsplash.com/photo-1701104282696-a1a69064baa1";


  return (
    <div className="pt-16 md:pt-20 bg-gray-50">
      <div className="relative h-[60vh] min-h-[350px] md:min-h-[450px]">
        <Carousel className="w-full h-full" opts={{ loop: destination.images.length > 1 }}>
          <CarouselContent className="h-full">
            <CarouselItem className="h-full relative">
              <img 
                className="w-full h-full object-cover"
                alt={destination.name}
                src={heroImage} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
              <div className="absolute bottom-8 left-8 text-white z-10 p-4">
                <h1 className="text-4xl md:text-6xl font-bold">{destination.name}</h1>
                <p className="text-lg md:text-xl">{destination.tagline}</p>
              </div>
            </CarouselItem>
            {destination.images
              .filter(img => img.url !== heroImage && destinationPageImages[destination.id] !== img.url) 
              .map((image, index) => (
                <CarouselItem key={index} className="h-full relative">
                  <img 
                    className="w-full h-full object-cover"
                    alt={image.alt || `${destination.name} - Image ${index + 2}`}
                    src={image.url} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                   <div className="absolute bottom-8 left-8 text-white z-10 p-4">
                    <p className="text-sm md:text-base">{image.text || image.alt}</p>
                  </div>
                </CarouselItem>
            ))}
          </CarouselContent>
          {destination.images.length > 1 && (
            <>
              <CarouselPrevious className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white border-none" />
              <CarouselNext className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white border-none" />
            </>
          )}
        </Carousel>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="mb-8">
          <Button variant="outline" onClick={() => navigate("/destinations")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Destinations
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div 
            className="lg:col-span-2 space-y-8"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-primary">About {destination.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">{destination.description}</p>
              </CardContent>
            </Card>

            {destination.itinerary && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl text-primary">Suggested Itinerary {destination.itinerary.source !== "Guwahati (Local)" ? `(from ${destination.itinerary.source})` : ""}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {destination.itinerary.days.map((day, index) => (
                      <div key={index} className="border-l-4 border-primary pl-4 py-2 bg-primary/5 rounded-r-md">
                        <h4 className="font-semibold text-lg mb-1">{day.day ? `Day ${day.day}: ` : ""}{day.title}</h4>
                        <ul className="list-disc list-inside text-gray-600 space-y-1">
                          {day.activities.map((activity, actIndex) => (
                            <li key={actIndex}>{activity}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </motion.div>

          <motion.div 
            className="lg:col-span-1 space-y-6"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Quick Facts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-3 text-primary" />
                  <span className="text-gray-700">State: {stateKey.charAt(0).toUpperCase() + stateKey.slice(1)}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 mr-3 text-primary" />
                  <span className="text-gray-700">Suggested Duration: {destination.duration}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-3 text-primary" />
                  <span className="text-gray-700">Best Time to Visit: {destination.bestTime}</span>
                </div>
                {destination.priceRange && (
                  <div className="flex items-center">
                    <IndianRupee className="h-5 w-5 mr-3 text-primary" />
                    <span className="text-gray-700">Price Range: {destination.priceRange}</span>
                  </div>
                )}
                {destination.itinerary && destination.itinerary.source !== "Guwahati (Local)" && (
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-3 text-primary" />
                    <span className="text-gray-700">Itinerary Starts From: {destination.itinerary.source}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Weather Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center">
                  <Sun className="h-5 w-5 mr-3 text-yellow-500" />
                  <span className="text-gray-700">Summer (Mar-Jun): Pleasant to warm, good for sightseeing.</span>
                </div>
                <div className="flex items-center">
                  <CloudRain className="h-5 w-5 mr-3 text-blue-500" />
                  <span className="text-gray-700">Monsoon (Jul-Sep): Heavy rainfall, lush greenery, some areas might be inaccessible.</span>
                </div>
                <div className="flex items-center">
                  <Sun className="h-5 w-5 mr-3 text-orange-400" />
                  <span className="text-gray-700">Autumn (Oct-Nov): Clear skies, pleasant, ideal for travel.</span>
                </div>
                 <div className="flex items-center">
                  <Users className="h-5 w-5 mr-3 text-blue-300" />
                  <span className="text-gray-700">Winter (Dec-Feb): Cool to cold, especially in higher altitudes. Snowfall in some areas.</span>
                </div>
              </CardContent>
            </Card>
            
            <Button size="lg" className="w-full bg-primary hover:bg-primary/90" onClick={handleBookNow}>
              Book This Destination
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default DestinationDetailPage;
