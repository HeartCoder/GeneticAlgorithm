
import React, { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Users, IndianRupee } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import { destinationsData } from "@/data/destinationsMaster";

const destinationImages = {
  "cherrapunji": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d4a4a3828aa2214cba3aea1001eb7ed5.jpg",
  "shillong": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg",
  "dawki": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/4bd73408677d8142fb0f79f4257cfafd.jpg",
  "mawlynnong": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/d63a95f696e4b875a8c1514ae90c5979.jpg",
  "tawang": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/5b9054aafa87ba20a9eb3c2f72756138.jpg",
  "ziro-valley": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/06d7c0128eb2277fd5655a00a3d3f86e.jpg",
  "bomdila": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/45352e7593c05a230fb4ec354cfcd24d.jpg",
  "namdapha-national-park": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/af808dadf7dbee597ca6946d07d2118c.jpg",
  "kaziranga-national-park": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/c507eeac7beace3abaa4c7767275caf7.jpg",
  "majuli-island": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/5f95556e235a02f5423efe9f50c9539b.jpg",
  "guwahati": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/38ca2f376f8bbcad3d6c9a110f87221e.jpg",
  "sivasagar": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/15a65f218b6a89fe2d494ffb02a8522b.jpg",
  "meghalaya-kaziranga-explorer": "https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/9bf271e7da63c6c8f4200539d26d4396.jpg" 
};

const DestinationCard = ({ destination, stateKey }) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    navigate(`/destinations/${stateKey}/${destination.id}`);
  };

  const cardImage = destinationImages[destination.id] || destination.images[0]?.url || "https://images.unsplash.com/photo-1492714284113-6e74f3a3d95c";


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-full"
    >
      <Card className="overflow-hidden destination-card h-full flex flex-col">
        <Carousel className="w-full relative">
          <CarouselContent>
              <CarouselItem className="relative h-56">
                <img 
                  className="w-full h-full object-cover"
                  alt={destination.images[0]?.alt || `${destination.name} image`}
                 src={cardImage} />
              </CarouselItem>
          </CarouselContent>
        </Carousel>
        <CardHeader className="pb-2">
          <CardTitle>{destination.name}</CardTitle>
          <CardDescription className="text-xs text-primary">{destination.tagline}</CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-sm text-gray-600 mb-3 line-clamp-3">{destination.description}</p>
          <div className="flex flex-col space-y-1 text-sm">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2 text-primary" />
              <span>Duration: {destination.duration}</span>
            </div>
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-2 text-primary" />
              <span>Best Time: {destination.bestTime}</span>
            </div>
            {destination.priceRange && (
              <div className="flex items-center">
                <IndianRupee className="h-4 w-4 mr-2 text-primary" />
                <span>Price: {destination.priceRange}</span>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full" onClick={handleViewDetails}>
            View Details & Itinerary
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};


const DestinationsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const phoneNumber = "8822608900";
  const countryCode = "+91";
  const whatsappLink = `https://wa.me/${countryCode}${phoneNumber}?text=Hello%2C%20I'm%20interested%20in%20booking%20a%20trip.`;

  useEffect(() => {
    if (location.hash) {
      const id = location.hash.substring(1);
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [location]);

  const handleBookTrip = () => {
     window.open(whatsappLink, '_blank');
  };

  return (
    <div className="pt-16 md:pt-20">
      <div className="relative h-[50vh] min-h-[300px] md:min-h-[400px]">
        <div className="absolute inset-0 z-0">
          <img 
            className="w-full h-full object-cover"
            alt="Panoramic view of North East India mountains and valleys"
           src="https://storage.googleapis.com/hostinger-horizons-assets-prod/0f07c0bc-e59f-42de-aec6-76edee202496/2bc195808b66a2c0f6136806545a269c.jpg" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30 z-10"></div>
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-20 h-full flex items-center">
          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl font-bold text-white mb-4"
            >
              Explore Our Destinations
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-gray-200"
            >
              Discover the hidden gems and popular attractions across Meghalaya, Arunachal Pradesh, and Assam. Each destination offers a unique blend of culture, nature, and adventure.
            </motion.p>
          </div>
        </div>
      </div>

      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <Tabs defaultValue="meghalaya" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="meghalaya" id="meghalaya-tab" className="text-sm md:text-base px-4 md:px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-white rounded-md">Meghalaya</TabsTrigger>
                <TabsTrigger value="arunachal" id="arunachal-tab" className="text-sm md:text-base px-4 md:px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-white rounded-md">Arunachal Pradesh</TabsTrigger>
                <TabsTrigger value="assam" id="assam-tab" className="text-sm md:text-base px-4 md:px-6 py-2 data-[state=active]:bg-primary data-[state=active]:text-white rounded-md">Assam</TabsTrigger>
              </TabsList>
            </div>

            {Object.keys(destinationsData).map((stateKey) => (
              <TabsContent key={stateKey} value={stateKey} id={stateKey}>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {destinationsData[stateKey].map((destination) => (
                    <DestinationCard key={destination.id} destination={destination} stateKey={stateKey} />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      <section className="py-16 bg-primary/10">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Explore These Amazing Destinations?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Contact us to plan your perfect itinerary starting from Guwahati, covering the best of North East India's natural beauty and cultural heritage.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90" onClick={handleBookTrip}>
            Book Your Trip Now
          </Button>
        </div>
      </section>
    </div>
  );
};

export default DestinationsPage;
